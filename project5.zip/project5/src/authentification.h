#include <gtk/gtk.h>
void ajouter(char seance[], char date[], char type[]);
void afficher();
int verifier(char login[], char password[]);
void afficher1(GtkWidget *plistview);
